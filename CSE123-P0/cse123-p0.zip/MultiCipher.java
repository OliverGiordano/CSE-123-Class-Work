// TODO: Write your implementation to MultiCipher here!
